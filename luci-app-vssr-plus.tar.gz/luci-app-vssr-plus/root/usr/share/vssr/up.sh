


# ------------------- VSSR一键更新脚本！ ------------------- 

wget -4 -O /usr/share/vssr/up.sh  https://raw.githubusercontent.com/LEDBO/up/master/up.sh && chmod 775 /usr/share/vssr/up.sh

wget -4 -O /usr/share/netdata/web/dashboard.js  https://raw.githubusercontent.com/LEDBO/up/master/dashboard.js && chmod 664 /usr/share/netdata/web/dashboard.js

wget -4 -O /usr/share/netdata/web/dashboard_info.js  https://raw.githubusercontent.com/LEDBO/up/master/dashboard_info.js && chmod 664 /usr/share/netdata/web/dashboard_info.js

wget -4 -O /usr/share/netdata/web/index.html  https://raw.githubusercontent.com/LEDBO/up/master/index.html && chmod 664 /usr/share/netdata/web/index.html

wget -4 -O /usr/share/netdata/web/main.js  https://raw.githubusercontent.com/LEDBO/up/master/main.js && chmod 664 /usr/share/netdata/web/main.js

wget -4 -O /usr/share/shadowsocksr/genred2config.sh  https://raw.githubusercontent.com/LEDBO/up/master/genred2config.sh && chmod 775 /usr/share/shadowsocksr/genred2config.sh

wget -4 -O /usr/share/shadowsocksr/ssrplusupdate.sh  https://raw.githubusercontent.com/LEDBO/up/master/ssrplusupdate.sh && chmod 775 /usr/share/shadowsocksr/ssrplusupdate.sh
								 
		
-------------------版本更新成功！ ------------------- >> 
